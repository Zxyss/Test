const { Message, Client, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');

module.exports = {
    name: 'yardım',
    description: 'Yardım menüsünü atar.',
    kategori: 'kullanıcı',
    izinler: ['SendMessages'],
    kurucu: false,
    /**
     * @param {Client} client
     * @param {Message} message
     */
    async execute(client, message, args, prefix) {
        const { author } = message;

        const modKomutlar = client.commands
            .filter(cmd => cmd.kategori === 'mod')
            .map(cmd => `📕 \`${prefix}${cmd.name}\`**: ${cmd.description}**`);

        const userKomutlar = client.commands
            .filter(cmd => cmd.kategori === 'kullanıcı')
            .map(cmd => `📗 \`${prefix}${cmd.name}\`**: ${cmd.description}**`);

        const embed = new EmbedBuilder()
            .setAuthor({ name: `${client.user.username} Komutlar`, iconURL: client.user.displayAvatarURL() })
            .setThumbnail(client.user.displayAvatarURL())
            .setDescription(`Şuan da ana yardım menüsündesin aşağıdaki menüyü kullanarak bir kategori seçebilirsin.\n\n📕 Yetkili komutları (**${modKomutlar.length}**)\n📗 Kullanıcı komutları (**${userKomutlar.length}**)`)
            .setColor('Blurple')
            .setFooter({ text: author.username, iconURL: author.displayAvatarURL() })

        const select = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`yardimSelect-${author.id}`)
                .setPlaceholder('Kategoriler')
                .addOptions(
                    new StringSelectMenuOptionBuilder()
                        .setLabel(`Yetkili (${modKomutlar.length})`)
                        .setDescription('Yetkili komutlarına göz at!')
                        .setEmoji('📕')
                        .setValue(`komut-yetkili`),
                    new StringSelectMenuOptionBuilder()
                        .setLabel(`Kullanıcı (${userKomutlar.length})`)
                        .setDescription('Kullanıcı komutlarına göz at!')
                        .setEmoji('📗')
                        .setValue(`komut-kullanıcı`),
                    new StringSelectMenuOptionBuilder()
                        .setLabel(`Sistemler`)
                        .setDescription('Sunucuda kurulu olan sistemlere göz at!')
                        .setEmoji('📘')
                        .setValue(`komut-sistemler`),
                )
        )

        return message.reply({ embeds: [embed], components: [select] });
    },
};