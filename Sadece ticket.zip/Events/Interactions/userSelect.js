const { UserSelectMenuInteraction, Client } = require('discord.js');
const db = require('mzrdb');

module.exports = {
    name: 'interactionCreate',
    /**
     * @param {UserSelectMenuInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        if (!interaction.isUserSelectMenu()) return;

        const { customId, channel, guild, users } = interaction;

        if (customId === 'destekUyeEkle') {
            const user = users.first();
            if (!user) return;

            await channel.permissionOverwrites.edit(user.id, {
                ViewChannel: true,
                SendMessages: true,
                AttachFiles: true,
                EmbedLinks: true,
                ReadMessageHistory: true
            });

            return await interaction.reply({ content: `${user} isimli üye destek talebine eklenmiştir.`, ephemeral: true });
        } else if (customId === 'destekUyeCikart') {
            const user = users.first();
            if (!user) return;

            await channel.permissionOverwrites.delete(user.id)

            return await interaction.reply({ content: `${user} isimli üye destek talebinden çıkartılmıştır.`, ephemeral: true });
        };
    },
};