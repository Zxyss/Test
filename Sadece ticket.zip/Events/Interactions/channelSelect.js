const { ChannelSelectMenuInteraction, Client, EmbedBuilder } = require('discord.js');
const db = require('mzrdb');

module.exports = {
    name: 'interactionCreate',
    /**
     * @param {ChannelSelectMenuInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        if (!interaction.isChannelSelectMenu()) return;

        const { customId, user, guild, channels, message } = interaction;
        const cId = customId.split('-')[0];
        const userId = customId.split('-')[1];
        let id = null;

        if (cId) id = interaction.values[0];
        if (user.id !== userId) return interaction.reply({ content: `Bu menüyü sadece komutu kullanan kişi kullanabilir.`, ephemeral: true });

        if (id && cId === 'destekLogAyar') {
            db.set(`destek.${guild.id}.log`, channels.first().id);

            const destekLog = db.get(`destek.${guild.id}.log`);
            const destekYetkili = db.get(`destek.${guild.id}.yetkili`);
            const destekKategori = db.get(`destek.${guild.id}.kategori`);

            const embed = new EmbedBuilder()
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription('Aşağıda ki menüden sistemleri kontrol edebilirsin.')
                .addFields(
                    { name: 'Destek Log Kanalı', value: `${destekLog ? `<#${destekLog}>` : 'Yok'}`, inline: false },
                    { name: 'Destek Yetkili Rolü', value: `${destekYetkili ? `<@&${destekYetkili}>` : 'Yok'}`, inline: false },
                    { name: 'Destek Kategorisi', value: `${destekKategori ? `<#${destekKategori}>` : 'Yok'}`, inline: false },
                )
                .setColor('Blurple')
                .setTimestamp()

            await interaction.message.edit({ embeds: [embed] });
            return interaction.reply({ content: `${channels.first()} kanalı, **Destek Log** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'destekKategoriAyar') {
            db.set(`destek.${guild.id}.kategori`, channels.first().id);

            const destekLog = db.get(`destek.${guild.id}.log`);
            const destekYetkili = db.get(`destek.${guild.id}.yetkili`);
            const destekKategori = db.get(`destek.${guild.id}.kategori`);

            const embed = new EmbedBuilder()
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription('Aşağıda ki menüden sistemleri kontrol edebilirsin.')
                .addFields(
                    { name: 'Destek Log Kanalı', value: `${destekLog ? `<#${destekLog}>` : 'Yok'}`, inline: false },
                    { name: 'Destek Yetkili Rolü', value: `${destekYetkili ? `<@&${destekYetkili}>` : 'Yok'}`, inline: false },
                    { name: 'Destek Kategorisi', value: `${destekKategori ? `<#${destekKategori}>` : 'Yok'}`, inline: false },
                )
                .setColor('Blurple')
                .setTimestamp()

            await interaction.message.edit({ embeds: [embed] });
            return interaction.reply({ content: `${channels.first().name} kategorisi, **Destek Kategorisi** olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'scrimKanalAyar') {
            db.set(`scrim.${guild.id}.kanal`, channels.first().id);

            return interaction.reply({ content: `${channels.first()} kanalı, **Scrim Oto Rol** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'hgbbGirisAyar') {
            db.set(`hgbb.${guild.id}.giris`, channels.first().id);

            return interaction.reply({ content: `${channels.first()} kanalı, **Giriş** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'hgbbCikisAyar') {
            db.set(`hgbb.${guild.id}.cikis`, channels.first().id);

            return interaction.reply({ content: `${channels.first()} kanalı, **Çıkış** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'basvuruLogAyar') {
            db.set(`basvuru.${guild.id}.log`, channels.first().id);

            return interaction.reply({ content: `${channels.first()} kanalı, **Başvuru Log** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'kanalLogAyar') {
            db.set(`kanalLog.${guild.id}`, channels.first().id);

            return interaction.reply({ content: `${channels.first()} kanalı, **Kanal Log** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'mesajLogAyar') {
            db.set(`mesajLog.${guild.id}`, channels.first().id);

            return interaction.reply({ content: `${channels.first()} kanalı, **Mesaj Log** kanalı olarak ayarlanmıştır.`, ephemeral: true });
        };
    },
};