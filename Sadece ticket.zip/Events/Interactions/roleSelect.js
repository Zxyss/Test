const { RoleSelectMenuInteraction, Client, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');
const db = require('mzrdb');

module.exports = {
    name: 'interactionCreate',
    /**
     * @param {RoleSelectMenuInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        if (!interaction.isRoleSelectMenu()) return;

        const { customId, user, guild, roles } = interaction;
        const cId = customId.split('-')[0];
        const userId = customId.split('-')[1];
        let id = null;

        if (cId) id = interaction.values[0];
        if (user.id !== userId) return interaction.reply({ content: `Bu menüyü sadece komutu kullanan kişi kullanabilir.`, ephemeral: true });

        if (id && cId === 'destekYetkiliAyar') {
            db.set(`destek.${guild.id}.yetkili`, roles.first().id);

            const destekLog = db.get(`destek.${guild.id}.log`);
            const destekYetkili = db.get(`destek.${guild.id}.yetkili`);
            const destekKategori = db.get(`destek.${guild.id}.kategori`);

            const embed = new EmbedBuilder()
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription('Aşağıda ki menüden sistemleri kontrol edebilirsin.')
                .addFields(
                    { name: 'Destek Log Kanalı', value: `${destekLog ? `<#${destekLog}>` : 'Yok'}`, inline: false },
                    { name: 'Destek Yetkili Rolü', value: `${destekYetkili ? `<@&${destekYetkili}>` : 'Yok'}`, inline: false },
                    { name: 'Destek Kategorisi', value: `${destekKategori ? `<#${destekKategori}>` : 'Yok'}`, inline: false },
                )
                .setColor('Blurple')
                .setTimestamp()

            await interaction.message.edit({ embeds: [embed] });
            return interaction.reply({ content: `${roles.first()} rolü, **Destek Yetkili** rolü olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'scrimOtorolAyar') {
            db.set(`scrim.${guild.id}.otorol`, roles.first().id);

            return interaction.reply({ content: `${roles.first()} rolü, **Scrim Oto Rol** rolü olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'basvuruYetkiliAyar') {
            db.set(`basvuru.${guild.id}.yetkili`, roles.first().id);

            return interaction.reply({ content: `${roles.first()} rolü, **Başvuru Yetkili** rolü olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'basvuruVerilecekAyar') {
            db.set(`basvuru.${guild.id}.verilecek`, roles.first().id);

            return interaction.reply({ content: `${roles.first()} rolü, **Başvuru Verilecek** rol olarak ayarlanmıştır.`, ephemeral: true });
        } else if (id && cId === 'butonRolAyar') {
            db.set(`butonRol.${guild.id}`, roles.first().id);

            const embed = new EmbedBuilder()
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
                .setDescription(`**${roles.first().name}** adlı rolü almak için aşağıda ki butona tıklaman yeterli!`)
                .setThumbnail(client.user.displayAvatarURL())
                .setColor('Green')
                .setTimestamp()

            const buton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel(roles.first().name)
                    .setStyle(ButtonStyle.Secondary)
                    .setCustomId(roles.first().id))

            await interaction.channel.send({ embeds: [embed], components: [buton] });
            return interaction.reply({ content: `${roles.first()} rolü, **Buton Rol** rolü olarak ayarlanmıştır.`, ephemeral: true });
        };
    },
};