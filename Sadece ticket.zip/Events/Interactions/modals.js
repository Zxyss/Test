const { ModalSubmitInteraction, Client, EmbedBuilder, codeBlock, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { defaultBasvuruSorular } = require('../../config.json');
const mzr = require('mzrdjs');
const db = require('mzrdb');

module.exports = {
    name: 'interactionCreate',
    /**
     * @param {ModalSubmitInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        if (!interaction.isModalSubmit()) return;

        const { fields, customId, guild, message, user } = interaction;

        if (customId === 'embedOlustur') {
            await interaction.reply({ content: 'Embed başarıyla oluşturulmuştur!', ephemeral: true });

            const baslik = fields.getTextInputValue(`embedOlustur-baslik`);
            const aciklama = fields.getTextInputValue(`embedOlustur-aciklama`);
            const hex = fields.getTextInputValue(`embedOlustur-hex`);
            const footer = fields.getTextInputValue(`embedOlustur-footer`);
            const thumbnail = fields.getTextInputValue(`embedOlustur-thumbnail`);

            const embed = new EmbedBuilder()
                .setDescription(aciklama)
                .setColor(hex)

            if (baslik) embed.setAuthor({ name: baslik, iconURL: client.user.displayAvatarURL() });
            if (footer) embed.setFooter({ text: footer, iconURL: client.user.displayAvatarURL() });
            if (thumbnail) embed.setThumbnail(thumbnail);

            return interaction.channel.send({ embeds: [embed] });
        } else if (customId === 'nedenSoyle') {
            await interaction.reply({ content: `Destek talebin <t:${mzr.timestamp(Date.now()) + 6}:R> kapatılacaktır.` });

            const logID = db.get(`destek.${guild.id}.log`);
            const log = client.channels.cache.get(logID);

            const talebiAçan = message.embeds[0].fields[0].value;
            const acilmaZaman = message.embeds[0].fields[1].value;
            const sebep = message.embeds[0].fields[2].value;
            const neden = fields.getTextInputValue('nedenBelirt');

            const messages = await interaction.channel.messages.fetch();
            const reserved = messages.reverse();

            let mesaj = `Destek talebin (${interaction.channel.name}) Mesajları\n\n`;
            reserved.each((msg) => {
                if (!msg.author.bot) mesaj += `${msg.author.username}: ${msg.content}\n`;
            });

            const embed = new EmbedBuilder()
                .setAuthor({ name: `Destek Talebi Kapatıldı!`, iconURL: client.user.displayAvatarURL() })
                .setThumbnail(user.displayAvatarURL())
                .setColor('Blurple')
                .addFields(
                    { name: 'Talebi Açan', value: `${talebiAçan}`, inline: false },
                    { name: 'Talebi Kapatan', value: `${user}`, inline: false },
                    { name: 'Talebin Açılma Zamanı', value: `${acilmaZaman}`, inline: false },
                    { name: 'Talebin Kapatılma Zamanı', value: `<t:${mzr.timestamp(Date.now())}:R>`, inline: false },
                    { name: 'Talebin Açılma Nedeni', value: `${sebep}`, inline: false },
                    { name: 'Tabin Kapatılma Nedeni', value: `${neden}`, inline: false },
                )

            const açanID = talebiAçan.match(/\d+/g);
            await client.users.fetch(açanID[0]).then(async (mzr) => {
                await mzr.send({ embeds: [embed] }).catch(() => { });
                return mzr.send({ content: codeBlock(mesaj) }).catch(() => { });
            }).catch(() => { });

            await log.send({ embeds: [embed] });
            await log.send({ content: codeBlock(mesaj) });

            setTimeout(async () => { await interaction.channel.delete(); }, 5000);
        } else if (customId === 'basvuruSorular') {
            await interaction.reply({ content: 'Başvurun başarıyla gönderildi, başarılar!', ephemeral: true });

            const soru1 = fields.getTextInputValue(`soru1`);
            const soru2 = fields.getTextInputValue(`soru2`);
            const soru3 = fields.getTextInputValue(`soru3`);
            const soru4 = fields.getTextInputValue(`soru4`);

            const logID = db.get(`basvuru.${guild.id}.log`);
            if (!logID) return interaction.reply({ content: 'Başvuru log kanalı ayarlanmamış!', ephemeral: true });

            const log = client.channels.cache.get(logID);

            let sorular = db.get(`basvuru.${guild.id}.soru`);
            if (!sorular) sorular = defaultBasvuruSorular;

            const embed = new EmbedBuilder()
                .setAuthor({ name: `${guild.name} Başvuru Sistemi`, iconURL: guild.iconURL() })
                .setThumbnail(guild.iconURL())
                .setDescription(`**${user.username}** \`(${user.id})\`\n**Kullanıcının Başvuru Formu**`)
                .addFields(
                    { name: sorular[0], value: soru1, inline: false },
                    { name: sorular[1], value: soru2, inline: false },
                    { name: sorular[2], value: soru3, inline: false },
                    { name: sorular[3], value: soru4, inline: false },
                )
                .setColor('#9daab9')
                .setTimestamp()

            const buton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('Kabul Et')
                    .setCustomId(`basvuruKabulEt-${user.id}`)
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✅'),
                new ButtonBuilder()
                    .setLabel('Reddet')
                    .setCustomId(`basvuruReddet-${user.id}`)
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('❌'))

            return log.send({ content: `${user}`, embeds: [embed], components: [buton] });
        };
    },
};